# BÁO CÁO LAB 11: KHỞI TẠO ỨNG DỤNG SPRING BOOT VÀ GIAO DIỆN THYMELEAF
**Học phần:** Công nghệ Java (IT3242)  
**Chương 4:** Phát triển ứng dụng với Spring Framework  
**Sinh viên thực hiện:** Trần Đức Hoàn  
**MSSV:** 2030022  
**Lớp:** DCCNTT14.10.1 (CNTT14-01)  
**Tên dự án:** `lab11-springboot-thymeleaf`  

---

## 1. MỤC TIÊU BÀI LAB
- Khởi tạo thành công dự án Spring Boot 3x sử dụng Maven và Java 17.
- Cấu hình các dependency `spring-boot-starter-web`, `spring-boot-starter-thymeleaf`, `spring-boot-devtools`.
- Tách biệt rõ ràng 3 tầng theo mô hình Spring MVC: **Controller**, **Model**, **View (Thymeleaf)**.
- Xây dựng các trang web động:
  - `/` (Home): Trang chủ nhận dữ liệu `title` và `message` từ `HomeController`.
  - `/about` (Giới thiệu): Hiển thị tên học phần, chương học và mô tả từ `HomeController`.
  - `/students` (Sinh viên): Hiển thị danh sách sinh viên mẫu bằng `th:each`.
  - `/contact` (Liên hệ): Hiển thị thông tin liên hệ Khoa CNTT.
  - `/courses` (Khóa học): Hiển thị danh sách 5 khóa học mẫu bằng `th:each`.
- Thiết kế hệ thống Menu điều hướng dùng chung qua Fragment và định dạng bằng CSS tùy chỉnh (`static/css/style.css`).

---

## 2. CẤU TRÚC PROJECT
```text
lab11-springboot-thymeleaf/
├── pom.xml
└── src/main/
    ├── java/vn/edu/eaut/lab11/
    │   ├── Lab11Application.java
    │   ├── controller/
    │   │   ├── HomeController.java
    │   │   ├── StudentController.java
    │   │   └── CourseController.java
    │   └── model/
    │       ├── Student.java
    │       └── Course.java
    └── resources/
        ├── application.properties
        ├── static/
        │   └── css/
        │       └── style.css
        └── templates/
            ├── layout.html
            ├── index.html
            ├── about.html
            ├── students.html
            ├── contact.html
            └── courses.html
```

---

## 3. LOGIC HOẠT ĐỘNG CỦA ỨNG DỤNG

### 3.1. Controller trong bài lab
Controller là lớp chịu trách nhiệm đón nhận HTTP Request từ trình duyệt người dùng, xử lý logic (nạp dữ liệu mẫu), sau đó đưa dữ liệu vào đối tượng `Model` và trả về tên file template Thymeleaf tương ứng.
- `HomeController`: Xử lý `/`, `/about`, `/contact`.
- `StudentController`: Xử lý `/students`.
- `CourseController`: Xử lý `/courses`.

### 3.2. Model dùng để làm gì?
`Model` đóng vai trò là chiếc "cặp chứa dữ liệu" trung gian giữa Controller và View. Dữ liệu được gán bằng câu lệnh `model.addAttribute("key", value)` trong Java sẽ được truyền trực tiếp sang file `.html` để Thymeleaf đọc và render.

### 3.3. Thymeleaf nhận dữ liệu như thế nào?
Thymeleaf đọc dữ liệu từ `Model` qua biểu thức `${key}`:
- `th:text="${message}"`: Điền văn bản động từ Controller vào thẻ HTML.
- `th:href="@{/students}"`: Tạo đường dẫn chuẩn trong ứng dụng Web.
- `th:each="s : ${students}"`: Duyệt qua danh sách và lặp lại các dòng `<tr>` trong bảng HTML.

### 3.4. Luồng xử lý khi người dùng truy cập các URL
1. Người dùng gõ URL (ví dụ: `http://localhost:8080/students`).
2. Spring Boot điều hướng Request đến `@GetMapping("/students")` trong `StudentController`.
3. `StudentController` tạo danh sách các đối tượng `Student` và gọi `model.addAttribute("students", students)`.
4. Controller trả về chuỗi `"students"`.
5. Spring Boot tìm file `templates/students.html`. Thymeleaf lặp danh sách qua `th:each` và trả về mã HTML hoàn chỉnh cho trình duyệt.

---

## 4. HƯỚNG DẪN CHẠY VÀ KIỂM THỬ

### 4.1. Lệnh build và chạy project
```bash
# Biên dịch dự án
mvn clean package

# Khởi chạy ứng dụng Spring Boot
mvn spring-boot:run
```

### 4.2. Danh sách các URL cần mở để chụp ảnh nộp bài
1. **Trang chủ (`/`)**: `http://localhost:8080/`
2. **Trang Giới thiệu (`/about`)**: `http://localhost:8080/about`
3. **Trang Danh sách Sinh viên (`/students`)**: `http://localhost:8080/students`
4. **Trang Danh sách Khóa học (`/courses`)**: `http://localhost:8080/courses`
5. **Trang Liên hệ (`/contact`)**: `http://localhost:8080/contact`
